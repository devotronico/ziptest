-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Giu 07, 2018 alle 19:22
-- Versione del server: 10.1.31-MariaDB
-- Versione PHP: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `comments`
--

CREATE TABLE `comments` (
  `comment_ID` int(12) NOT NULL,
  `post_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `comment` text NOT NULL,
  `c_datecreated` datetime NOT NULL,
  `c_dateformatted` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `comments`
--

INSERT INTO `comments` (`comment_ID`, `post_id`, `user_id`, `comment`, `c_datecreated`, `c_dateformatted`) VALUES
(3, 2, 1, 'Donec id augue ac odio vehicula lacinia. Etiam justo turpis, dictum ut sem ut, auctor tempor ex.', '2018-05-21 10:34:10', '21 maggio 2018 , 10:34'),
(7, 2, 1, 'Nam volutpat neque sit amet quam euismod, eget ultricies velit facilisis. Vestibulum mattis eleifend neque ut mollis.', '2018-05-21 13:19:09', '21 maggio 2018 , 13:19'),
(8, 1, 1, ' Duis dapibus sodales lacus et consectetur. Proin ac nunc pellentesque, sodales felis eu, dictum est. ', '2018-05-21 13:38:14', '21 maggio 2018 , 13:38'),
(10, 1, 1, ' Curabitur interdum placerat viverra. Duis dapibus sodales lacus et consectetur. ', '2018-05-21 13:40:09', '21 maggio 2018 , 13:40'),
(12, 1, 1, 'Donec et risus neque. Etiam massa augue, venenatis eget eros tincidunt, pretium ornare quam. ', '2018-05-21 14:15:51', '21 maggio 2018 , 14:15'),
(13, 1, 2, 'Donec et risus neque. Etiam massa augue, venenatis eget eros tincidunt, pretium ornare quam. ', '2018-05-21 14:17:12', '21 maggio 2018 , 14:17'),
(14, 1, 2, 'Donec et risus neque. Etiam massa augue, venenatis eget eros tincidunt, pretium ornare quam. ', '2018-05-21 14:17:16', '21 maggio 2018 , 14:17'),
(15, 2, 2, 'Nunc ut egestas felis. Sed semper a ligula id ultrices. Curabitur a varius urna. Maecenas vitae ', '2018-05-21 14:18:09', '21 maggio 2018 , 14:18'),
(16, 2, 2, 'ttis turpis gravida at. Quisque placerat blandit nunc et lu', '2018-05-21 14:18:14', '21 maggio 2018 , 14:18'),
(17, 1, 3, 'nvallis, metus nec tempus accumsan, sapien neque e', '2018-05-21 15:12:31', '21 maggio 2018 , 15:12'),
(18, 2, 3, 'uctus et ultrices posuere cubilia Curae; ', '2018-05-21 15:12:40', '21 maggio 2018 , 15:12'),
(20, 10, 1, 'risus egestas eget. Nunc ac risus ante. Aenean sit ame', '2018-06-02 11:34:03', '2 giugno 2018 , 11:34'),
(21, 1, 9, 'Commento di broli', '2018-06-03 19:50:57', '3 giugno 2018 , 19:50'),
(22, 10, 1, 'pien aliquam venenatis. Nunc tincidunt justo ut convallis bibendum', '2018-06-04 20:36:23', '4 giugno 2018 , 20:36');

-- --------------------------------------------------------

--
-- Struttura della tabella `posts`
--

CREATE TABLE `posts` (
  `post_ID` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(32) NOT NULL,
  `message` text NOT NULL,
  `messtruncate` varchar(255) NOT NULL,
  `datecreated` datetime NOT NULL,
  `dateformatted` varchar(30) NOT NULL,
  `num_comments` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `posts`
--

INSERT INTO `posts` (`post_ID`, `user_id`, `title`, `image`, `message`, `messtruncate`, `datecreated`, `dateformatted`, `num_comments`) VALUES
(1, 1, 'Titolo 1', '5b1904b8a5fc14.13437343.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin pharetra malesuada lorem, eget varius mauris ornare eget. In risus est, congue sit amet pharetra at, tincidunt nec lectus. Cras est est, hendrerit at diam in, vulputate convallis turpis. Phasellus ut nulla tempus massa molestie sagittis. Vivamus venenatis, tellus non pharetra hendrerit, leo est maximus tortor, eget iaculis ligula magna at leo. Sed eu felis quis erat tincidunt maximus. Nunc hendrerit diam ipsum, at interdum felis vulputate ut. Vivamus efficitur euismod magna, sit amet eleifend massa fermentum sed. Nullam eget consectetur metus, eu vestibulum mi. Donec sagittis, mauris sed pellentesque consequat, metus tortor condimentum magna, non ullamcorper est lorem a turpis. \r\n<pre class=\"prettyprint\">\r\npublic function getPosts($currentPage=1){ \r\n   \r\n    if ( isset($_COOKIE[\'user_id\']) ) {\r\n         $Auth = new Auth($this->conn);\r\n         $Auth->loginWithCookie(); \r\n    }\r\n\r\n    $totalPosts = $this->Post->totalPosts();\r\n    $link=\"posts\";\r\n    if ( empty($totalPosts ) ) { \r\n        $this->page = \'empty\';\r\n        $files=[$this->device.\'.navbar-blog\', \'post.empty\'];\r\n        $this->content = View(\'blog\', $files, compact(\'link\', \'page\')); \r\n\r\n     } else {\r\n        $this->page = \'blog\';\r\n        $postForPage = 3;  \r\n        for ($i=0, $postStart=-$postForPage; $i<$currentPage; $postStart+=$postForPage, $i++);\r\n        $posts = $this->Post->pagePosts($postStart, $postForPage); \r\n        $files=[$this->device.\'.navbar-blog\', \'post.all\', $this->device.\'.pagination\'];\r\n        $this->content = View(\'blog\', $files, compact(\'link\', \'posts\', \'currentPage\', \'totalPosts\', \'postForPage\')); \r\n     }\r\n}\r\n</pre>\r\nCras et suscipit orci, at efficitur enim. Etiam mattis odio ipsum. Pellentesque imperdiet odio id magna congue volutpat. Aliquam sodales nibh quis mi placerat, a suscipit arcu vehicula. Aliquam vitae finibus diam. Quisque gravida a felis vitae vestibulum.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin pharetra', '2018-06-07 12:11:04', '7 giugno 2018 , 12:11', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `users`
--

CREATE TABLE `users` (
  `ID` tinyint(3) UNSIGNED NOT NULL,
  `user_type` varchar(13) NOT NULL,
  `user_image` varchar(32) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_email` varchar(32) NOT NULL,
  `user_pass` varchar(60) NOT NULL,
  `user_registered` datetime NOT NULL,
  `user_activation_key` varchar(255) NOT NULL,
  `user_status` tinyint(4) NOT NULL,
  `user_num_posts` smallint(6) NOT NULL,
  `user_num_comments` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `users`
--

INSERT INTO `users` (`ID`, `user_type`, `user_image`, `user_name`, `user_email`, `user_pass`, `user_registered`, `user_activation_key`, `user_status`, `user_num_posts`, `user_num_comments`) VALUES
(1, 'administrator', '5b116493d05604.23646581.jpg', 'Daniele', 'dmanzi83@hotmail.it', '$2y$10$ZlCExWiLwoHAVg5L1aUXE.psO.NmtPVbmZ56Hj4hreoGuxtn35kv6', '2018-05-20 23:16:34', '766ebcd59621e305170616ba3d3dac32', 1, 22, 7),
(2, 'reader', '5b02c5625ce0f7.05570864.jpg', 'doe', 'doe@mail.it', '$2y$10$kwXEu3LYoTVe.x0I1/rJzOgzlukWIZ.LFFcWCdIzetfqzhxdFuW/.', '2018-05-20 23:56:59', 'f61d6947467ccd3aa5af24db320235dd', 1, 3, 2),
(3, 'reader', '5b02c5ea4e9307.50161303.jpg', 'bob', 'bob@mail.it', '$2y$10$2JCJytkPudhF7guzQ.afSOd4cEUroUitUrjJMy4LxajSzgfX7OcXq', '2018-05-21 15:11:28', 'ba3866600c3540f67c1e9575e213be0a', 1, 0, 2),
(8, 'reader', '5b13e715332654.16120828.jpg', 'zac', 'zac@mail.it', '$2y$10$t4fyKcFwV8zbg9SoKqlll.K8lWzyVoqfe3Fs5NzdEUUuKgEG1vE2W', '2018-06-03 15:03:17', '81448138f5f163ccdba4acc69819f280', 0, 0, 0),
(9, 'reader', '5b142a63b863e9.43110501.jpg', 'broli05', 'broli05@protonmail.com', '$2y$10$74VHTLP2A8eaNlE8CrBpkuotA.jcH4xFIfqseP6SwylpUjy.hGhxG', '2018-06-03 15:06:20', '1728efbda81692282ba642aafd57be3a', 1, 0, 1),
(10, 'reader', '5b16fa02cfb1d4.83956084.jpg', 'foo', 'foo@mail.it', '$2y$10$mA2.GhMTbOEhx0fIzUFHR.tukoJpjFQ1Ktt.vpab7rY6bGlGpOhiq', '2018-06-05 23:00:50', '8a0e1141fd37fa5b98d5bb769ba1a7cc', 0, 0, 0),
(11, 'reader', 'default.jpg', 'bar', 'bar@mail.it', '$2y$10$KnU61GHrt/OdKdfs86r6ge1dv4P3y.pIdlHjCAPMvq9m0nDjvhDDO', '2018-06-05 23:07:10', '07a96b1f61097ccb54be14d6a47439b0', 0, 0, 0);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_ID`);

--
-- Indici per le tabelle `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_ID`);

--
-- Indici per le tabelle `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_ID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT per la tabella `posts`
--
ALTER TABLE `posts`
  MODIFY `post_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `users`
--
ALTER TABLE `users`
  MODIFY `ID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
